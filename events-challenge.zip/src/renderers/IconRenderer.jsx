import React from "react";

const IconRenderer = ({ value, size='1x'}) => (
        <span>
            <i class={'fas fa-' + value +' fa-'+size}></i>
        </span>
    );


export default IconRenderer;