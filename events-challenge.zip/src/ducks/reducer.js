
import { combineReducers } from "redux";
import * as types from "./types";

const findIndex  = (array, id) => {
    let index = -1;
    for (let i = 0; i < array.length; i++) {
        const element = array[i];
        if(element.id === id){
            index = i;
            break;
        }
    }
    return index;
}


const initialEvents = {
    data: [],
    isLoading: false,
    isDeleting: false
}

const eventsReducer = (state = initialEvents, action) => {
    switch (action.type) {
        case types.GET_EVENTS_REQUESTED: 
        case types.POST_EVENT_REQUESTED: 
        case types.DELETE_EVENT_REQUESTED: 
            return {
                ...state,
                isLoading: true,
            }
        case types.DELETE_EVENT_REQUESTED:
            return {
                ...state,
                isDeleting: true,
            }
        case types.GET_EVENTS_SUCCEEDED:
            return {
                ...state,
                data: action.payload,
                isLoading: false,
            }
        case types.POST_EVENT_SUCCEEDED:
            return  {
                ...state,
                data: [
                    action.payload,
                    ...state.data
                ],
                isLoading: false,
            };

        case types.DELETE_EVENT_SUCCEEDED:
            const itemIndex = findIndex(state.data, action.payload.id)
            return {
                ...state,
                data: [
                    ...state.data.slice(0, itemIndex), 
                    ...state.data.slice(itemIndex + 1)
                ],
                isLoading: false,
            }
        case types.GET_EVENTS_FAILED:
        case types.POST_EVENT_FAILED:
        case types.DELETE_EVENT_FAILED:
            return {
                ...state,
                data: [],
                isLoading: false,
            }
            
        default: return state;
    }
}

const selectedRowReducer = (state = null, action) => {
    switch (action.type) {
        case types.ROW_SELECTED:
            return action.payload;

        default: return state;
    }
}


const reducer = combineReducers({
    events: eventsReducer,
    selectedRow: selectedRowReducer
});

export default reducer;