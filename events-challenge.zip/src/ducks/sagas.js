import { call, put, takeEvery } from 'redux-saga/effects'
import * as Api from '../api/Api';
import * as types from "./types";

function* fetchEvents() {
    try {
        const { data } = yield call(Api.getEvents);
        yield put({ type: types.GET_EVENTS_SUCCEEDED, payload:data });
    } catch (e) {
        yield put({ type: types.GET_EVENTS_FAILED, message: e.message });
    }
}

function* saga() {
    yield takeEvery(types.GET_EVENTS_REQUESTED, fetchEvents);
    yield takeEvery(types.POST_EVENT_REQUESTED, addEvent);
    yield takeEvery(types.DELETE_EVENT_REQUESTED, deleteEvent);
}

function* addEvent({payload}) {
    try {
        const { data } = yield call(Api.postEvent, payload);
        yield put({ type: types.POST_EVENT_SUCCEEDED, payload:data });
        yield put({ type: types.ROW_SELECTED, payload: null });
    } catch (e) {
        yield put({ type: types.POST_EVENT_FAILED, message: e.message });
    }
}


function* deleteEvent({payload}) {
    try {
        const { data } = yield call(Api.deleteEvent, payload.id);
        yield put({ type: types.DELETE_EVENT_SUCCEEDED, payload });
        yield put({ type: types.ROW_SELECTED, payload:null });
    } catch (e) {
        yield put({ type: types.DELETE_EVENT_FAILED, message: e.message });
    }
}


export default saga;