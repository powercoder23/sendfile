import * as types from "./types";

export const getEvents = () => ({ type: types.GET_EVENTS_REQUESTED });

export const addEvent = (payload) => ({ type: types.POST_EVENT_REQUESTED, payload })

export const deleteEvent = (payload) => ({ type: types.DELETE_EVENT_REQUESTED, payload })

export const selectRow = (row) => ({ type: types.ROW_SELECTED, payload: row});
