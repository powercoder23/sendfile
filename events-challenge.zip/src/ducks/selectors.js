
const getEventList = (state) => state.events.data || [];

const isLoading = (state) => state.events.isLoading;

const isDeleting = (state) => state.events.isDeleting;

const getSelectedRow = (state) => state.selectedRow || null;

export {
    getEventList, isLoading, isDeleting, getSelectedRow
};