import axios from 'axios';
import {GET_EVENTS, POST_EVENT, DELETE_EVENT} from '../utils/Constants';
  

export const getEvents = () => axios.get(GET_EVENTS);

export const postEvent = (eventObject) => axios.post(POST_EVENT, eventObject);

export const deleteEvent = (id) => axios.delete(DELETE_EVENT + id);

