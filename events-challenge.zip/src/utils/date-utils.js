export class DateTimeUtils {
    static timestamp = () => new Date().getTime();
} 