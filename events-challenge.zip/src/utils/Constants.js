export const BASEURL = 'https://forgetful-elephant.herokuapp.com/';

export const GET_EVENTS = BASEURL + 'events';
export const POST_EVENT = BASEURL + 'events';
export const DELETE_EVENT = BASEURL + 'events/';