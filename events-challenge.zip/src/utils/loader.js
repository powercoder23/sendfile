import React from 'react';

export const LoadingOverlay = ({ show }) => {
    if (show) {
        return <div className="backdrop">
            <div className="spinner">
                <i class="fas fa-spinner fa-spin fa-4x"></i>
            </div>
        </div>
    } else {
        return null
    }
}