
import React, { Component } from 'react';
import { connect } from "react-redux";

import * as selectors from "../ducks/selectors";
import * as actions from '../ducks/actions';
import IconRenderer from "../renderers/IconRenderer";


class SidePanel extends Component {

    constructor(props) {
        super(props);
        this.deleteEvent = this.deleteEvent.bind(this);
    }

    deleteEvent(item) {
        this.props.deleteEvent(item);
    }


    render() {
        const { selectedRow } = this.props;

        if (!selectedRow) {
            return <p>
                <strong>No Rows Selected</strong>
            </p>

        }
        return (
            <>
                <p>
                    <IconRenderer value={selectedRow.icon} size="5x" />
                </p>
                <p>
                    <strong>Title</strong> : {selectedRow.title}
                </p>

                <p>
                    <strong>Type</strong> : {selectedRow.type}
                </p>

                <p>
                    <strong>Service ID</strong> : {selectedRow.serviceId}
                </p>

                <p>
                    <strong>Data</strong> : {selectedRow.data}
                </p>

                <p>
                    <button onClick={this.deleteEvent.bind(this, selectedRow)} className="btn btn-danger">Delete</button>
                </p>

            </>
        );
        
    }
}


const mapDispatchToProps = dispatch => {
    return {
        deleteEvent: (event) => dispatch(actions.deleteEvent(event)),
    }
}

const mapStateToProps = (state, ownProps) => {
    return {
        selectedRow: selectors.getSelectedRow(state)
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(SidePanel);
