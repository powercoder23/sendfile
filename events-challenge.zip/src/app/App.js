
import React, { Component } from 'react';
import logo from '../logo.svg';
import './App.scss';
import { connect } from "react-redux";

import * as selectors  from "../ducks/selectors";
import * as actions from '../ducks/actions';
import { LoadingOverlay, DateTimeUtils } from "../utils";
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-balham.css';
import SidePanel from '../sidepanel/SidePanel';
import IconRenderer  from "../renderers/IconRenderer";

class App extends Component {

	constructor(props) {
		super(props);
		this.deleteEvent = this.deleteEvent.bind(this);
		this.addEvent = this.addEvent.bind(this);


		this.state = {
			userInput: '',
			columnDefs: [{
				headerName: "Icon", field: "icon", width: 100, cellRenderer: 'iconRenderer',
			}, {
				headerName: "Title", field: "title", width: 300
			}, {
				headerName: "Type", field: "type", width: 100
			}],
			frameworkComponents: {
				iconRenderer: IconRenderer,
			}
		}
		this.types = ['A', 'B', 'C', 'D'];
		this.serviceIDs = ['abcd', 'efgh', 'qwerty', 'xyz'];
		this.icons = ['air-freshener', 'ambulance', 'bus', 'bus-alt'];
		this.titles = [
			'A short summary of the event',
			'A long summary description of the event',
			'A very short one short summary description of the event'
		];
		this.allData = [
			'The event payload 1',
			'The event payload 2',
			'The event payload 3'
		]

		this.props.getEvents();
	}

	getRandomInArray(items) {
		return items[Math.floor(Math.random() * items.length)];
	}

	addEvent() {
		const eventObj = {
			"type":  this.getRandomInArray(this.types),
			"serviceId": this.getRandomInArray(this.serviceIDs),
			"icon": this.getRandomInArray(this.icons),
			"timestamp": DateTimeUtils.timestamp,
			"title": this.getRandomInArray(this.titles),
			"data": this.getRandomInArray(this.allData)
		}
		this.props.addEvent(eventObj);
	}

	deleteEvent(item) {
		this.props.deleteEvent(item);
	}

	onSelectionChanged() {
		var selectedRows = this.gridApi.getSelectedRows();
		if (selectedRows[0]){
			this.props.selectRow(selectedRows[0]);
		}
		
	}

	onGridReady = params => {
		this.gridApi = params.api;
		this.gridColumnApi = params.columnApi;
	}

	sizeToFit() {
		if (this.gridApi){
			this.gridApi.sizeColumnsToFit();
		}
	}

	componentDidUpdate(){
		this.sizeToFit()
	}

	render() {
		const { eventsList, isLoading } = this.props;

		return (
			<>
				<LoadingOverlay show={isLoading} />
				<button className="btn" onClick={this.addEvent}> Trigget Event</button>
				<div className="outer " >
					<div className="inner border">
					{
						!!eventsList.length &&

							<div
								className="ag-theme-balham grid-container"
							>
								<AgGridReact
									columnDefs={this.state.columnDefs}
									rowSelection='single'
									frameworkComponents={this.state.frameworkComponents}
									onGridReady={this.onGridReady}
									onSelectionChanged={this.onSelectionChanged.bind(this)}
									rowData={eventsList}>
								</AgGridReact>
							</div>
					}

					{
						!eventsList.length && <div>No Events</div>
					}
					</div>
					<div className="inner border">
						<SidePanel />
					</div>
				</div>

				
			</>
		);
	}
}


const mapDispatchToProps = dispatch => {
	return {
		getEvents: () => dispatch(actions.getEvents()),
		addEvent: (event) => dispatch(actions.addEvent(event)),
		deleteEvent: (event) => dispatch(actions.deleteEvent(event)),
		selectRow: (row) => dispatch(actions.selectRow(row))
	}
}

const mapStateToProps = (state, ownProps) => {
	return {
		eventsList: selectors.getEventList(state),
		isDeleting: selectors.isDeleting(state),
		isLoading: selectors.isLoading(state),
	}
}

export default connect(mapStateToProps, mapDispatchToProps)(App);
