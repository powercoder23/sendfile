/* eslint-disable */

export const APP_ID = "fbf712a5a83d7305c3cda4ca8fe7ef29";

/* eslint-enable */