import React, { Component } from "react";

import { connect } from "react-redux";
import { fetchData } from "./actions/weatherStation";

import WeatherForecast from './components/WeatherForecast';


class App extends Component {

  constructor(props){
    super(props);

    this.state = {
      message: 'loading'
    }
  }

  componentDidMount() {
    const detectLocation = new Promise((resolve, reject) => {
      if ("geolocation" in navigator) {
        navigator.geolocation.getCurrentPosition((position) => {

          resolve(position.coords);
        }, (error) => {

          if (error.code === error.PERMISSION_DENIED) {
            console.error("Error detecting location.");
            this.setState({
              message: 'Error detecting location.'
            })
            
          }
        }, { timeout: 5000 });
      }
    });

    detectLocation.then((location) => {

      console.log(location)
      this.props.dispatch(fetchData(location));
    }).catch(() => {

      this.props.dispatch(fetchData("london"));
    });
  }

  render() {
    const { forecast } = this.props;
    const { message} = this.state;

    return (
      forecast === null ? (
        <div className="loading">
          <div className="spinner">{message}</div>
        </div>
      ) : (
          <div>
            <WeatherForecast data={forecast} />
          </div>
        )
    );
  }
}

const mapStateToProps = (state) => {
  console.log(state.weatherStation.data)
  return {
    forecast: state.weatherStation.data
  }
}

export default connect(
  mapStateToProps,
  null
)(App)