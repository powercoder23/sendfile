import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tooltip-demo',
  templateUrl: './tooltip-demo.component.html'
})
export class TooltipDemoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
