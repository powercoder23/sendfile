window.ShoppingCart = function () {

    var self = this;

    var getFromStorage = function () {
        var cartItems = {}, storage = localStorage.getItem('cartItems')
        if (storage != null) {
            cartItems = JSON.parse(storage);
        }
        return cartItems;
    }

    var getAllItems = function () {
        var cartItems = getFromStorage();
        return Object.keys(cartItems).length;
    }

    var updateCartCount = function () {
        $('.cartCount').text(getAllItems);
    }

    var clear = function () {
        localStorage.clear();
        if (self.close){
            self.close();
        }
        updateCartCount();
    }

    var renderPage = function (products) {

        var cartItems = getFromStorage();
        var filterCartItems = products.filter(function (product) {
            return cartItems.hasOwnProperty(product.id);
        }).map(function (filteredProduct) {
            filteredProduct.isCartItem = true;
            filteredProduct.quantity = cartItems[filteredProduct.id]
            return filteredProduct
        });
        $('.all-products').removeClass('visible');
        if (filterCartItems.length) {
            var list = $('.cart .products-list');
            var theTemplateScript = $("#products-template").html();
            //Compile the template
            var theTemplate = Handlebars.compile(theTemplateScript);
            list.html(theTemplate(filterCartItems));

            // Show the page.
            $('.cart').addClass('visible');
            $('.cart .close').click(self.close);
            $('.cart .clear').click(clear);
        } else {
            $('.error h3').text('Cart is empty');
            $('.error').addClass('visible');
        }


    }

    var initialize = function (params) {
        self.close = params.close;
         
        updateCartCount();    
    }
    

    return {
        initialize: initialize,
        getAllItems: getAllItems,
        renderPage: renderPage,
        close: close,
        addProduct: function (id) {
            var cartItems = getFromStorage();

            if (cartItems.hasOwnProperty(id)) {
                cartItems[id]++;
            } else {
                cartItems[id] = 1;
            }

            localStorage.setItem('cartItems', JSON.stringify(cartItems));
            updateCartCount()
        },

        removeProduct: function (id) {

            var cartItems = getFromStorage();

            if (cartItems.hasOwnProperty(id) && cartItems[id] > 1) {
                cartItems[id]--;
            } else {
                delete cartItems[id];
            }

            localStorage.setItem('cartItems', JSON.stringify(cartItems));
            updateCartCount()
        }
    }

}()

