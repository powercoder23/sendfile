QUnit.test("Shopping cart ", function (assert) {
    assert.ok(ShoppingCart, "Passed!");
});